const username = 'ilox';

export async function getGeoCity(city) {
  const dataUrl = `http://api.geonames.org/searchJSON?formatted=true&q=${city}&username=${username}&style=full`;
  
  try {
    const response = await fetch(dataUrl);
    if (!response.ok) {
      throw new Error('Failed to fetch data');
    }
    const data = await response.json();
    const cityData = {
      latitude: data.geonames[0].lat,
      longitude: data.geonames[0].lng,
      population: data.geonames[0].population,
      countryCode: data.geonames[0].countryCode,
    };
    console.log(cityData);
    return cityData;
  } catch (error) {
    console.log(error);
  }
}
