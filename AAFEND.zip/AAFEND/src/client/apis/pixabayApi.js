const pixabayKey = '35448873-82f0a0a5307332db1dcb16ebe';

export async function getImageURL(city, country) {
  const cityEndpoint = `https://pixabay.com/api/?key=${pixabayKey}&q=${city}&image_type=photo&pretty=true&category=places`;
  const countryEndpoint = `https://pixabay.com/api/?key=${pixabayKey}&q=${country}&image_type=photo&pretty=true&category=places`;

  try {
    let response = await fetch(cityEndpoint);
    if (response.ok) {
      let jsonRes = await response.json();
      if (jsonRes.totalHits === 0) {
        response = await fetch(countryEndpoint);
        if (response.ok) {
          jsonRes = await response.json();
          if (jsonRes.totalHits === 0) {
            throw new Error('No images found for city or country');
          }
          return jsonRes.hits[0].largeImageURL;
        }
        throw new Error('Failed to fetch images for country');
      }
      return jsonRes.hits[0].largeImageURL;
    }
    throw new Error('Failed to fetch images for city');
  } catch (error) {
    console.log(error);
  }
}
