import {
  getGeoCity,
  getImageURL,
  getWeatherForecast,
  getCountryInfo
} from './js/app.js';
import {
  getCity,
  getTripStart,
  getTripEnd
} from './js/form.js';
import {
  createTripCard,
  recentTrip
} from './js/model.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/style.scss';
import 'bootstrap';
import $ from 'jquery';

const trip = {};

async function handleSave(event) {
  event.preventDefault();

  try {
    const res = await fetch('/saveData', {
      method: 'POST',
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        trip
      })
    });
    if (res.ok) {
      const data = await res.json();
      recentTrip(data);
      return data;
    }
  } catch (error) {
    console.log(error);
  }
}

function handleCancel(event) {
  event.preventDefault();
  $('#tripModal').modal('toggle');
  $('.caption').css('display', 'block');
}

async function handleSearch(event) {
  event.preventDefault();

  trip.city = getCity();
  trip.start = getTripStart();
  trip.end = getTripEnd();

  const geocity = await getGeoCity(trip.city);

  trip.latitude = geocity.latitude;
  trip.longitude = geocity.longitude;
  trip.countryCode = geocity.countryCode;

  trip.weatherForecast = await getWeatherForecast(geocity.latitude, geocity.longitude);

  const countryInfo = await getCountryInfo(trip.countryCode);

  trip.country = countryInfo.name;
  trip.countryFlag = countryInfo.flag;

  trip.image = await getImageURL(trip.city, trip.country);

  console.log(trip);

  createTripCard(trip);
}

/* Add event listeners */
$('#button_search').on('click', handleSearch);

$('.trip_save').on('click', handleSave);

$('.trip_cancel').each(function() {
  $(this).on('click', handleCancel);
});
