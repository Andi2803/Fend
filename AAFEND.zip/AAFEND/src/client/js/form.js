// use const instead of let to declare these functions
const getCity = () => {
  let city = document.getElementById('city').value;

  // use template literals to capitalize the first letter of the city name
  city = `${city.charAt(0).toUpperCase()}${city.slice(1).toLowerCase()}`;

  console.log(city);

  return city;
};

const getTripStart = () => {
  const date = document.getElementById('date_start').value.split('-');

  // use destructuring to return the date in YYYY-MM-DD format
  const [year, month, day] = date;
  return `${year}-${month}-${day}`;
};

const getTripEnd = () => {
  const date = document.getElementById('date_end').value.split('-');

  // use destructuring to return the date in YYYY-MM-DD format
  const [year, month, day] = date;
  return `${year}-${month}-${day}`;
};

const countdown = (start, end) => {
  const tripStart = Date.parse(start);
  const tripEnd = Date.parse(end);

  const countdown = tripEnd - tripStart;

  const daysLeft = Math.ceil(countdown / 86400000);

  //console.log(daysLeft);

  return daysLeft;
};

// export statements
export { getCity, getTripStart, getTripEnd, countdown };