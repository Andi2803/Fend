import 'bootstrap';
import $ from 'jquery';
import { countdown } from './form.js';

const recentTrip = (trip) => {
  const tripStart = getTripDate(trip.start);
  const tripEnd = getTripDate(trip.end);
  const daysLeft = countdown(new Date(), trip.start);
  const weather = getWeatherInfo(trip.weatherForecast, daysLeft, tripStart);

  const div = document.createElement('div');
  div.classList.add('col-md-4');
  const tripsContainer = document.querySelector('.trips-container');
  tripsContainer.appendChild(div);

  div.innerHTML = `
    <div class="col-md-12">
      <div class="card mb-12">
        <div class="row no-gutters">
          <div class="col-md-12">
            <img src="${trip.image}" class="card-img" alt="Picture of Travel Destination">
          </div>
          <div class="col-md-12">
            <div class="card-body">
              <h4 class="card-title trip_title"><img src="${trip.countryFlag}" class="flag"> ${trip.city}, ${trip.country}</h4>
              <h6 class="mt-0">Departure:<span style="color:crimson"> ${tripStart}</span></h6>
              <h6 class="mt-0">Return:<span style="color:crimson">${tripEnd}</span> </h6>
              <h6 class="mt-0">Duration:<span style="color:crimson"> ${countdown(trip.start, trip.end)}</span> days</h6>
              <span class="trip_countdown">Your trip to <span style="color:crimson">${trip.city} </span> is <span style="color:crimson">${daysLeft}</span>  days away</span>
              <p>Trip date weather: <span style="color:crimson">${weather.temperature}&deg;F</span>, <span style="color:crimson">${weather.summary}</span> </p>
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div>
    </div>`;
};


const createTripCard = async (trip) => {
  const { city, country, countryFlag, start, end, image, weatherForecast } = trip;

  // Create trip card element
  const cardEl = document.createElement('div');
  cardEl.classList.add('card');

  // Create trip header element
  const headerEl = document.createElement('div');
  headerEl.classList.add('card-header');
  headerEl.innerHTML = `
    <img src="${countryFlag}" class="flag" />
    <h2>${city}, ${country}</h2>
  `;
  cardEl.appendChild(headerEl);

  // Create trip body element
  const bodyEl = document.createElement('div');
  bodyEl.classList.add('card-body');
  bodyEl.innerHTML = `
    <div class="media">
      <img src="${image}" class="images" />
      <div class="media-body">
        <h3 class="media_heading">${city}, ${country}</h3>
        <p class="media_heading">${getTripDate(start)} - ${getTripDate(end)}</p>
        <p class="media_heading">${countdown(start, end)} days</p>
        <p class="media_heading">Your trip to ${city} is ${countdown(new Date(), start)} day(s) away</p>
        <p class="trip_weather"></p>
      </div>
    </div>
  `;
  cardEl.appendChild(bodyEl);

  // Get weather info and update trip card
  const weather = await getWeatherInfo(weatherForecast, countdown(start, end), getTripDate(start));
  const weatherEl = bodyEl.querySelector('.trip_weather');
  weatherEl.innerHTML = `
    Trip date weather: 
    <span style="color:crimson">${weather.temperature}&deg;F</span>, 
    <span style="color:crimson">${weather.summary}</span>
  `;

  return cardEl;
};


const getWeatherInfo = (weatherForecast, daysLeft, date) => {
  console.log('weatherForecast:', weatherForecast);
  console.log('daysLeft:', daysLeft);
  console.log('date:', date);

  const weatherData = weatherForecast.data[daysLeft];
  console.log('weatherData:', weatherData);

  return {
    temperature: weatherData.temp,
    summary: weatherData.weather.description,
  };
};


  
const getTripDate = (date) => {
    const months = ["January",
                    "February",
                    "March", 
                    "April", 
                    "May", 
                    "June",
                    "July", 
                    "August", 
                    "September",
                    "October", 
                    "November", 
                    "December"];
  
const days = ["Sunday", 
                  "Monday", 
                  "Tuesday", 
                  "Wednesday", 
                  "Thursday", 
                  "Friday", 
                  "Saturday"];
  
const tripDate = new Date(date);

const tripDateText = `${days[tripDate.getDay()]}, ${months[tripDate.getMonth()]} ${tripDate.getDate()}, ${tripDate.getFullYear()}`;

    return tripDateText;
  };
  
export { createTripCard, recentTrip };