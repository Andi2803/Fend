// Import dependencies
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const async = require('express-async-errors')
const fetch = require('node-fetch-npm');

// Create Express app
const app = express();

// Enable CORS
app.use(cors());

// Parse request bodies as JSON
app.use(bodyParser.json());

// Parse URL-encoded request bodies
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files from the "static" directory
app.use(express.static('./dist'));

// Serve the index.html file
app.get('/', (req, res) => {
  res.status(200).send('./dist/index.html');
});


// Define trips array
const trips = [];

// Save trip data
app.post('/saveData', (req, res, next) => {
  const { trip } = req.body;
  if (!trip) {
    return res.status(400).json('Bad Request');
  }
  trips.push(trip);
  res.status(201).send(trip);
});

// Get weather forecast
app.post('/forecast', async (req, res, next) => {
  if (req.body.endpoint !== " ") {
    const endpoint = req.body.endpoint;
    try {
      const response = await fetch(endpoint);
      if (response.ok) {
        const jsonRes = await response.json();
        res.status(201).send(jsonRes);
      }
    } catch (error) {
      console.log(error);
    }
  } else {
    res.status(400).json('Bad Request');
  }
});

// Start server
const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

// Export app
module.exports = app;

