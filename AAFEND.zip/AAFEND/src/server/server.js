// Import dependencies
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import asyncHandler from 'express-async-handler';
import fetch from 'node-fetch';
import path from 'path';

const __dirname = path.resolve();

// Create Express app
const app = express();

// Enable CORS
app.use(cors());

// Parse request bodies as JSON
app.use(express.json());

// Parse URL-encoded request bodies
app.use(express.urlencoded({ extended: false }));

// Serve static files from the "static" directory
app.use(express.static(path.join(__dirname, './dist')));

// Serve the index.html file
app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'src/client/view/index.html'));
});


// Define trips array
const trips = [];

// Save trip data
app.post('/saveData', (req, res, next) => {
  const { trip } = req.body;
  if (!trip) {
    return res.status(400).json('Bad Request');
  }
  trips.push(trip);
  res.status(201).send(trip);
});

// Get weather forecast
app.post('/forecast', asyncHandler(async (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) {
    return res.status(400).json('Bad Request');
  }
  const response = await fetch(endpoint);
  if (response.ok) {
    const jsonRes = await response.json();
    res.status(200).send(jsonRes);
  } else {
    throw new Error('Failed to fetch weather data');
  }
}));

// Start server
const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

// Export app
export default app;

